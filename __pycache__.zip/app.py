from flask import Flask, redirect, url_for, session, request
from controllers.auth_controller import auth_blueprint
from controllers.dashboard_controller import dashboard_blueprint
from extensions import mysql
from controllers.career_guidance_controller import career_blueprint  # Import Career Guidance Controller
from flask import Flask, render_template  # Import render_template
from controllers.assignments_controller import assignments_blueprint
from controllers.health_controller import health_blueprint
from controllers.polls_controller import polls_blueprint
from controllers.events_controller import events_blueprint
from controllers.gaming_controller import gaming_blueprint
from controllers.semwise_controller import semwise_blueprint
from controllers.attendance_controller import attendance_blueprint

app = Flask(__name__)

# Configure MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = '1234'  # Replace with your password
app.config['MYSQL_DB'] = 'test'  # Replace with your database name

app.secret_key = 'your_secret_key'  # Required for session management

# Register Blueprints
app.register_blueprint(auth_blueprint, url_prefix='/auth')
app.register_blueprint(dashboard_blueprint, url_prefix='/dashboard')  # Register the correct dashboard blueprint
app.register_blueprint(career_blueprint)
from controllers.manners_controller import manners_blueprint
app.register_blueprint(health_blueprint)
app.register_blueprint(polls_blueprint)
app.register_blueprint(events_blueprint)
app.register_blueprint(gaming_blueprint)
app.register_blueprint(semwise_blueprint)
app.register_blueprint(attendance_blueprint)


# Force redirect to the registration page when opening the server
@app.route('/')
def home():
    if 'user_id' in session:  # Check if user is logged in
        return redirect(url_for('dashboard.dashboard_home'))  # If logged in, go to dashboard
    return redirect(url_for('auth.register'))  # Otherwise, go to register page first

# Check user session on every request
@app.before_request
def check_user_session():
    # Skip check for login and register routes
    if 'user_id' not in session and request.endpoint not in ['auth.login', 'auth.register']:
        return redirect(url_for('auth.login'))  # Redirect to login if no session
@app.route('/roadmap')
def roadmap():
    return render_template('roadmap.html')  # Path to roadmap.html directly in templates
@app.route('/career_guidance')
def career_home():
    return render_template('career_guidance.html')  # Path to your career guidance page

@app.route('/manners')
def manners_home():
    return render_template('manners_home.html')  # Path to your manners page

app.register_blueprint(manners_blueprint)
app.register_blueprint(assignments_blueprint)

# Initialize MySQL
mysql.init_app(app)

if __name__ == '__main__':
    app.run(debug=True)
