// Add interactivity here
document.addEventListener('DOMContentLoaded', function() {
    console.log("Welcome to the Student Dashboard!");
});
